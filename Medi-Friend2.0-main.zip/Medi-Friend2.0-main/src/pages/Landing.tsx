import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Pill, Clock, Bell, Search } from 'lucide-react';

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/30">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center mb-8">
            <div className="p-4 rounded-full bg-primary/10">
              <Pill className="h-16 w-16 text-primary" />
            </div>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">
            Medi-Friend
          </h1>
          
          <p className="text-2xl text-primary mb-4">
            Never Miss a Dose Again 💊
          </p>
          
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
            Your smart companion for medication reminders. Stay on track with your health routine with timely alerts and comprehensive medicine information.
          </p>

          <div className="flex gap-4 justify-center mb-16">
            <Button size="lg" onClick={() => navigate('/login')}>
              Get Started
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate('/login')}>
              Sign In
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="p-6 rounded-lg bg-card">
              <div className="p-3 rounded-lg bg-primary/10 w-fit mx-auto mb-4">
                <Clock className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Timely Reminders</h3>
              <p className="text-sm text-muted-foreground">
                Get accurate notifications in IST timezone with both browser alerts and in-app popups
              </p>
            </div>

            <div className="p-6 rounded-lg bg-card">
              <div className="p-3 rounded-lg bg-primary/10 w-fit mx-auto mb-4">
                <Bell className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Smart Alerts</h3>
              <p className="text-sm text-muted-foreground">
                Audio and visual notifications that work even when the app is minimized
              </p>
            </div>

            <div className="p-6 rounded-lg bg-card">
              <div className="p-3 rounded-lg bg-primary/10 w-fit mx-auto mb-4">
                <Search className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Drug Information</h3>
              <p className="text-sm text-muted-foreground">
                Instantly search and view medicine details, uses, and manufacturer info
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Landing;
