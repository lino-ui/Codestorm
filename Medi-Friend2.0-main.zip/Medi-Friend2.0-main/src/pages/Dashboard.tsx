import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authService } from '@/services/authService';
import { reminderService, Reminder } from '@/services/reminderService';
import { notificationService } from '@/services/notificationService';
import { ReminderForm } from '@/components/ReminderForm';
import { ReminderCard } from '@/components/ReminderCard';
import { MedicineSearch } from '@/components/MedicineSearch';
import { AlarmPopup } from '@/components/AlarmPopup';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { LogOut, Bell, BellOff, Pill } from 'lucide-react';

const Dashboard = () => {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [editingReminder, setEditingReminder] = useState<Reminder | null>(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [activeAlarm, setActiveAlarm] = useState<Reminder | null>(null);
  const [worker, setWorker] = useState<Worker | null>(null);

  useEffect(() => {
    const user = authService.getCurrentUser();
    if (!user) {
      navigate('/login');
      return;
    }
    setCurrentUser(user);
    loadReminders(user);
    
    // Request notification permission
    notificationService.requestPermission();

    // Initialize Web Worker for background alarm checking
    const alarmWorker = new Worker(
      new URL('../workers/alarmWorker.ts', import.meta.url),
      { type: 'module' }
    );

    alarmWorker.onmessage = (e) => {
      if (e.data.type === 'alarm') {
        const reminder = reminders.find(r => r.id === e.data.reminderId);
        if (reminder && notificationsEnabled) {
          handleAlarm(reminder);
        }
      }
    };

    setWorker(alarmWorker);

    return () => {
      alarmWorker.terminate();
    };
  }, [navigate]);

  useEffect(() => {
    if (worker && currentUser) {
      const enabledReminders = reminders.filter(r => r.enabled && r.status === 'upcoming');
      worker.postMessage({
        type: 'start',
        reminders: enabledReminders.map(r => ({ id: r.id, time: r.time, enabled: r.enabled })),
      });
    }
  }, [reminders, worker, currentUser]);

  const loadReminders = (userEmail: string) => {
    const userReminders = reminderService.getUserReminders(userEmail);
    setReminders(userReminders);
  };

  const handleAlarm = (reminder: Reminder) => {
    setActiveAlarm(reminder);
    
    if (notificationService.getPermissionStatus() === 'granted') {
      notificationService.showNotification(
        '💊 Medicine Reminder',
        {
          body: `Time to take ${reminder.name} - ${reminder.dosage}`,
          requireInteraction: true,
        }
      );
    }
  };

  const handleAddReminder = (data: { name: string; dosage: string; time: string }) => {
    if (!currentUser) return;

    if (editingReminder) {
      reminderService.updateReminder(currentUser, editingReminder.id, data);
      toast.success('Reminder updated successfully');
      setEditingReminder(null);
    } else {
      reminderService.addReminder(currentUser, data);
      toast.success('Reminder added successfully');
    }

    loadReminders(currentUser);
  };

  const handleDeleteReminder = (id: string) => {
    if (!currentUser) return;
    reminderService.deleteReminder(currentUser, id);
    toast.success('Reminder deleted');
    loadReminders(currentUser);
  };

  const handleMarkTaken = () => {
    if (!currentUser || !activeAlarm) return;
    reminderService.markAsTaken(currentUser, activeAlarm.id);
    loadReminders(currentUser);
    setActiveAlarm(null);
    toast.success('Marked as taken');
  };

  const handleLogout = () => {
    authService.logout();
    toast.success('Logged out successfully');
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/30">
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Pill className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Medi-Friend</h1>
                <p className="text-sm text-muted-foreground">{currentUser}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                {notificationsEnabled ? (
                  <Bell className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <BellOff className="h-4 w-4 text-muted-foreground" />
                )}
                <Label htmlFor="notifications" className="text-sm cursor-pointer">
                  Alerts
                </Label>
                <Switch
                  id="notifications"
                  checked={notificationsEnabled}
                  onCheckedChange={setNotificationsEnabled}
                />
              </div>
              
              <Button variant="outline" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <ReminderForm
              onSubmit={handleAddReminder}
              editingReminder={editingReminder}
              onCancelEdit={() => setEditingReminder(null)}
            />

            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Your Reminders</h2>
              {reminders.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Pill className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No reminders yet. Add your first reminder above!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {reminders.map((reminder) => (
                    <ReminderCard
                      key={reminder.id}
                      reminder={reminder}
                      onEdit={setEditingReminder}
                      onDelete={handleDeleteReminder}
                      isActive={activeAlarm?.id === reminder.id}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          <div>
            <MedicineSearch />
          </div>
        </div>
      </main>

      {activeAlarm && (
        <AlarmPopup
          reminder={activeAlarm}
          onDismiss={() => setActiveAlarm(null)}
          onMarkTaken={handleMarkTaken}
        />
      )}
    </div>
  );
};

export default Dashboard;
