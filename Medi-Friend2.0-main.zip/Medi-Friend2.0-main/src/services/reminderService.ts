export interface Reminder {
  id: string;
  name: string;
  dosage: string;
  time: string;
  status: 'upcoming' | 'taken' | 'missed';
  enabled: boolean;
}

const REMINDERS_KEY = 'medifriend_reminders';

export const reminderService = {
  getUserReminders: (userEmail: string): Reminder[] => {
    const allReminders = localStorage.getItem(REMINDERS_KEY);
    if (!allReminders) return [];
    
    try {
      const remindersData = JSON.parse(allReminders);
      return remindersData[userEmail] || [];
    } catch {
      return [];
    }
  },

  saveUserReminders: (userEmail: string, reminders: Reminder[]): void => {
    const allReminders = localStorage.getItem(REMINDERS_KEY);
    const remindersData = allReminders ? JSON.parse(allReminders) : {};
    
    remindersData[userEmail] = reminders;
    localStorage.setItem(REMINDERS_KEY, JSON.stringify(remindersData));
  },

  addReminder: (userEmail: string, reminder: Omit<Reminder, 'id' | 'status' | 'enabled'>): Reminder => {
    const reminders = reminderService.getUserReminders(userEmail);
    const newReminder: Reminder = {
      ...reminder,
      id: Date.now().toString(),
      status: 'upcoming',
      enabled: true,
    };
    
    reminders.push(newReminder);
    reminderService.saveUserReminders(userEmail, reminders);
    return newReminder;
  },

  updateReminder: (userEmail: string, id: string, updates: Partial<Reminder>): void => {
    const reminders = reminderService.getUserReminders(userEmail);
    const index = reminders.findIndex(r => r.id === id);
    
    if (index !== -1) {
      reminders[index] = { ...reminders[index], ...updates };
      reminderService.saveUserReminders(userEmail, reminders);
    }
  },

  deleteReminder: (userEmail: string, id: string): void => {
    const reminders = reminderService.getUserReminders(userEmail);
    const filtered = reminders.filter(r => r.id !== id);
    reminderService.saveUserReminders(userEmail, filtered);
  },

  markAsTaken: (userEmail: string, id: string): void => {
    reminderService.updateReminder(userEmail, id, { status: 'taken' });
  },
};
