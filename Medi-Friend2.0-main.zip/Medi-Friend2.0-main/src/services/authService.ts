export interface User {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface AuthState {
  isAuthenticated: boolean;
  currentUser: string | null;
}

const USERS_KEY = 'medifriend_users';
const AUTH_KEY = 'medifriend_auth';

export const authService = {
  signup: (email: string, password: string): { success: boolean; message: string } => {
    const users = authService.getAllUsers();
    
    if (users.find(u => u.email === email)) {
      return { success: false, message: 'Email already registered' };
    }

    users.push({ email, password });
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    return { success: true, message: 'Account created successfully' };
  },

  login: (email: string, password: string, rememberMe: boolean = false): { success: boolean; message: string } => {
    const users = authService.getAllUsers();
    const user = users.find(u => u.email === email && u.password === password);

    if (!user) {
      return { success: false, message: 'Invalid email or password' };
    }

    const authState: AuthState = {
      isAuthenticated: true,
      currentUser: email,
    };

    if (rememberMe) {
      localStorage.setItem(AUTH_KEY, JSON.stringify(authState));
    } else {
      sessionStorage.setItem(AUTH_KEY, JSON.stringify(authState));
    }

    return { success: true, message: 'Login successful' };
  },

  logout: () => {
    localStorage.removeItem(AUTH_KEY);
    sessionStorage.removeItem(AUTH_KEY);
  },

  getCurrentUser: (): string | null => {
    const authData = localStorage.getItem(AUTH_KEY) || sessionStorage.getItem(AUTH_KEY);
    if (!authData) return null;
    
    try {
      const auth: AuthState = JSON.parse(authData);
      return auth.isAuthenticated ? auth.currentUser : null;
    } catch {
      return null;
    }
  },

  isAuthenticated: (): boolean => {
    return authService.getCurrentUser() !== null;
  },

  getAllUsers: (): User[] => {
    const usersData = localStorage.getItem(USERS_KEY);
    return usersData ? JSON.parse(usersData) : [];
  },
};
