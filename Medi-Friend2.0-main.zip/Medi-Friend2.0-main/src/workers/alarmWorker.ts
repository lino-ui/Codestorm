// Web Worker for reliable background alarm checking
let checkInterval: ReturnType<typeof setInterval> | undefined;

interface AlarmMessage {
  type: 'start' | 'stop' | 'update';
  reminders?: Array<{ id: string; time: string; enabled: boolean }>;
}

self.onmessage = (e: MessageEvent<AlarmMessage>) => {
  const { type, reminders } = e.data;

  if (type === 'start' && reminders) {
    if (checkInterval) {
      clearInterval(checkInterval);
    }

    checkInterval = setInterval(() => {
      const now = new Date();
      const istOffset = 5.5 * 60 * 60 * 1000;
      const istTime = new Date(now.getTime() + istOffset);
      
      const currentTime = istTime.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
        timeZone: 'UTC'
      });

      reminders.forEach(reminder => {
        if (reminder.enabled && reminder.time === currentTime) {
          self.postMessage({
            type: 'alarm',
            reminderId: reminder.id,
            time: currentTime,
          });
        }
      });
    }, 1000);
  }

  if (type === 'stop') {
    if (checkInterval) {
      clearInterval(checkInterval);
    }
  }
};

export {};
