import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Search, Loader2, AlertCircle, Info } from 'lucide-react';

interface DrugInfo {
  brand_name?: string;
  generic_name?: string;
  purpose?: string;
  route?: string;
  manufacturer_name?: string;
}

export const MedicineSearch = () => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [drugInfo, setDrugInfo] = useState<DrugInfo | null>(null);
  const [error, setError] = useState<string | null>(null);

  const searchDrug = async () => {
    if (!query.trim()) return;

    setLoading(true);
    setError(null);
    setDrugInfo(null);

    try {
      const response = await fetch(
        `https://api.fda.gov/drug/label.json?search=openfda.brand_name:"${encodeURIComponent(query)}"&limit=1`
      );

      if (!response.ok) {
        throw new Error('Medicine not found');
      }

      const data = await response.json();

      if (data.results && data.results.length > 0) {
        const result = data.results[0];
        setDrugInfo({
          brand_name: result.openfda?.brand_name?.[0],
          generic_name: result.openfda?.generic_name?.[0],
          purpose: result.purpose?.[0],
          route: result.openfda?.route?.[0],
          manufacturer_name: result.openfda?.manufacturer_name?.[0],
        });
      } else {
        setError('No information found for this medicine');
      }
    } catch (err) {
      setError('Unable to fetch medicine information. Please try again.');
      console.error('Search error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    searchDrug();
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <Info className="h-5 w-5 text-primary" />
        <h2 className="text-xl font-semibold text-foreground">Search Medicine Info</h2>
      </div>
      
      <form onSubmit={handleSubmit} className="flex gap-2 mb-4">
        <Input
          placeholder="Enter medicine name..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="flex-1"
        />
        <Button type="submit" disabled={loading || !query.trim()}>
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Search className="h-4 w-4" />
          )}
        </Button>
      </form>

      {error && (
        <div className="flex items-start gap-2 p-4 bg-destructive/10 border border-destructive/20 rounded-lg text-destructive">
          <AlertCircle className="h-5 w-5 mt-0.5 flex-shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      )}

      {drugInfo && (
        <div className="space-y-3 bg-secondary/50 rounded-lg p-4">
          {drugInfo.brand_name && (
            <div>
              <p className="text-sm font-medium text-muted-foreground">Brand Name</p>
              <p className="text-foreground">{drugInfo.brand_name}</p>
            </div>
          )}
          {drugInfo.generic_name && (
            <div>
              <p className="text-sm font-medium text-muted-foreground">Generic Name</p>
              <p className="text-foreground">{drugInfo.generic_name}</p>
            </div>
          )}
          {drugInfo.purpose && (
            <div>
              <p className="text-sm font-medium text-muted-foreground">Purpose</p>
              <p className="text-foreground text-sm">{drugInfo.purpose}</p>
            </div>
          )}
          {drugInfo.route && (
            <div>
              <p className="text-sm font-medium text-muted-foreground">Route</p>
              <p className="text-foreground">{drugInfo.route}</p>
            </div>
          )}
          {drugInfo.manufacturer_name && (
            <div>
              <p className="text-sm font-medium text-muted-foreground">Manufacturer</p>
              <p className="text-foreground">{drugInfo.manufacturer_name}</p>
            </div>
          )}
        </div>
      )}
    </Card>
  );
};
