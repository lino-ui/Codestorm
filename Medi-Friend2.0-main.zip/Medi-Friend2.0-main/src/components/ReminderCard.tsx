import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Reminder } from '@/services/reminderService';
import { Pill, Clock, Edit, Trash2, CheckCircle2 } from 'lucide-react';

interface ReminderCardProps {
  reminder: Reminder;
  onEdit: (reminder: Reminder) => void;
  onDelete: (id: string) => void;
  isActive?: boolean;
}

export const ReminderCard = ({ reminder, onEdit, onDelete, isActive }: ReminderCardProps) => {
  const getStatusBadge = () => {
    switch (reminder.status) {
      case 'taken':
        return <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">Taken</Badge>;
      case 'missed':
        return <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">Missed</Badge>;
      default:
        return <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">Upcoming</Badge>;
    }
  };

  return (
    <Card className={`p-4 transition-all duration-300 ${isActive ? 'ring-2 ring-primary shadow-lg alarm-highlight' : ''}`}>
      <div className="flex items-start justify-between">
        <div className="flex gap-3 flex-1">
          <div className={`p-2 rounded-lg ${isActive ? 'bg-primary/20' : 'bg-primary/10'}`}>
            <Pill className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-foreground mb-1">{reminder.name}</h3>
            <p className="text-sm text-muted-foreground mb-2">{reminder.dosage}</p>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1 text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span>{reminder.time}</span>
              </div>
              {getStatusBadge()}
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onEdit(reminder)}
            className="h-8 w-8"
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete(reminder.id)}
            className="h-8 w-8 text-destructive hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      {reminder.status === 'taken' && (
        <div className="flex items-center gap-1 mt-3 text-sm text-accent">
          <CheckCircle2 className="h-4 w-4" />
          <span>Dose taken</span>
        </div>
      )}
    </Card>
  );
};
