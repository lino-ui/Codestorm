import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Reminder } from '@/services/reminderService';
import { Plus, Save } from 'lucide-react';

interface ReminderFormProps {
  onSubmit: (data: { name: string; dosage: string; time: string }) => void;
  editingReminder?: Reminder | null;
  onCancelEdit?: () => void;
}

export const ReminderForm = ({ onSubmit, editingReminder, onCancelEdit }: ReminderFormProps) => {
  const [name, setName] = useState('');
  const [dosage, setDosage] = useState('');
  const [time, setTime] = useState('');

  useEffect(() => {
    if (editingReminder) {
      setName(editingReminder.name);
      setDosage(editingReminder.dosage);
      setTime(convertTo24Hour(editingReminder.time));
    }
  }, [editingReminder]);

  const convertTo24Hour = (time12h: string): string => {
    const [time, modifier] = time12h.split(' ');
    let [hours, minutes] = time.split(':');
    
    if (hours === '12') {
      hours = '00';
    }
    
    if (modifier === 'PM') {
      hours = (parseInt(hours, 10) + 12).toString();
    }
    
    return `${hours.padStart(2, '0')}:${minutes}`;
  };

  const convertTo12Hour = (time24h: string): string => {
    const [hours, minutes] = time24h.split(':');
    let hour = parseInt(hours, 10);
    const modifier = hour >= 12 ? 'PM' : 'AM';
    
    if (hour === 0) {
      hour = 12;
    } else if (hour > 12) {
      hour = hour - 12;
    }
    
    return `${hour.toString().padStart(2, '0')}:${minutes} ${modifier}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !dosage || !time) return;

    const time12h = convertTo12Hour(time);
    onSubmit({ name, dosage, time: time12h });
    
    // Reset form
    setName('');
    setDosage('');
    setTime('');
  };

  const handleCancel = () => {
    setName('');
    setDosage('');
    setTime('');
    onCancelEdit?.();
  };

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold text-foreground mb-4">
        {editingReminder ? 'Edit Reminder' : 'Add New Reminder'}
      </h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="medicine-name">Medicine Name</Label>
          <Input
            id="medicine-name"
            placeholder="e.g., Paracetamol"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="dosage">Dosage</Label>
          <Input
            id="dosage"
            placeholder="e.g., 1 tablet, 10ml"
            value={dosage}
            onChange={(e) => setDosage(e.target.value)}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="time">Time</Label>
          <Input
            id="time"
            type="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            required
          />
        </div>

        <div className="flex gap-3 pt-2">
          <Button type="submit" className="flex-1">
            {editingReminder ? (
              <>
                <Save className="h-4 w-4 mr-2" />
                Update Reminder
              </>
            ) : (
              <>
                <Plus className="h-4 w-4 mr-2" />
                Add Reminder
              </>
            )}
          </Button>
          {editingReminder && (
            <Button type="button" variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
          )}
        </div>
      </form>
    </Card>
  );
};
