import { useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Reminder } from '@/services/reminderService';
import { X, Pill } from 'lucide-react';

interface AlarmPopupProps {
  reminder: Reminder;
  onDismiss: () => void;
  onMarkTaken: () => void;
}

export const AlarmPopup = ({ reminder, onDismiss, onMarkTaken }: AlarmPopupProps) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Create alarm sound (simple beep using Web Audio API)
    const audioContext = new AudioContext();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    gainNode.gain.value = 0.3;
    
    oscillator.start();
    
    const beepInterval = setInterval(() => {
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
    }, 1000);

    return () => {
      clearInterval(beepInterval);
      oscillator.stop();
      audioContext.close();
    };
  }, []);

  const istTime = new Date().toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
      <Card className="alarm-card w-full max-w-md mx-4 p-6 shadow-2xl border-2 border-primary animate-in zoom-in duration-300">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full bg-primary/10">
              <Pill className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground">Time to take your medicine!</h2>
              <p className="text-sm text-muted-foreground mt-1">{istTime}</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onDismiss} className="h-8 w-8">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="bg-secondary/50 rounded-lg p-4 mb-6">
          <p className="text-lg font-semibold text-foreground mb-1">{reminder.name}</p>
          <p className="text-muted-foreground">Dosage: {reminder.dosage}</p>
          <p className="text-sm text-muted-foreground mt-2">Scheduled: {reminder.time}</p>
        </div>

        <div className="flex gap-3">
          <Button 
            onClick={onMarkTaken} 
            className="flex-1"
            size="lg"
          >
            Mark as Taken
          </Button>
          <Button 
            onClick={onDismiss} 
            variant="outline" 
            className="flex-1"
            size="lg"
          >
            Dismiss
          </Button>
        </div>
      </Card>
    </div>
  );
};
