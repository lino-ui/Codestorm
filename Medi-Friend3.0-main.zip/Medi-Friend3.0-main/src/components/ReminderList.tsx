import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Trash2, CheckCircle } from "lucide-react";
import { Reminder } from "@/types/auth";

interface ReminderListProps {
  reminders: Reminder[];
  onUpdate: (id: string, updates: Partial<Reminder>) => void;
  onDelete: (id: string) => void;
}

const ReminderList = ({ reminders, onUpdate, onDelete }: ReminderListProps) => {
  if (reminders.length === 0) {
    return (
      <Card className="card-elevated">
        <CardContent className="py-12 text-center text-muted-foreground">
          <p>No reminders yet. Add your first reminder above! 💊</p>
        </CardContent>
      </Card>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "upcoming":
        return "default";
      case "taken":
        return "secondary";
      case "missed":
        return "destructive";
      default:
        return "default";
    }
  };

  return (
    <div className="space-y-3">
      <h2 className="text-xl font-semibold">Your Reminders</h2>
      <div className="grid gap-3">
        {reminders.map((reminder) => (
          <Card key={reminder.id} className="card-elevated">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-3">
                    <h3 className="font-semibold text-lg">{reminder.medicineName}</h3>
                    <Badge variant={getStatusColor(reminder.status)}>
                      {reminder.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{reminder.dosage}</p>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-primary" />
                    <span className="font-medium">{reminder.time}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  {reminder.status === "upcoming" && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onUpdate(reminder.id, { status: "taken" })}
                    >
                      <CheckCircle className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => onDelete(reminder.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ReminderList;
