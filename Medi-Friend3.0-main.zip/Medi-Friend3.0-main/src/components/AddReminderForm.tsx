import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus } from "lucide-react";
import { Reminder } from "@/types/auth";
import { useToast } from "@/hooks/use-toast";

interface AddReminderFormProps {
  onAdd: (reminder: Reminder) => void;
}

const AddReminderForm = ({ onAdd }: AddReminderFormProps) => {
  const { toast } = useToast();
  const [medicineName, setMedicineName] = useState("");
  const [dosage, setDosage] = useState("");
  const [hour, setHour] = useState("12");
  const [minute, setMinute] = useState("00");
  const [period, setPeriod] = useState("AM");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!medicineName || !dosage) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    const time = `${hour}:${minute} ${period}`;
    const reminder: Reminder = {
      id: Date.now().toString(),
      medicineName,
      dosage,
      time,
      status: "upcoming",
      createdAt: new Date().toISOString(),
    };

    onAdd(reminder);
    toast({
      title: "Reminder Added! ✅",
      description: `Set for ${time}`,
    });

    // Reset form
    setMedicineName("");
    setDosage("");
    setHour("12");
    setMinute("00");
    setPeriod("AM");
  };

  return (
    <Card className="card-elevated">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plus className="h-5 w-5" />
          Add New Reminder
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="medicine">Medicine Name</Label>
              <Input
                id="medicine"
                placeholder="e.g., Paracetamol"
                value={medicineName}
                onChange={(e) => setMedicineName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dosage">Dosage</Label>
              <Input
                id="dosage"
                placeholder="e.g., 1 tablet, 10ml"
                value={dosage}
                onChange={(e) => setDosage(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Time</Label>
            <div className="flex gap-2">
              <Select value={hour} onValueChange={setHour}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 12 }, (_, i) => i + 1).map((h) => (
                    <SelectItem key={h} value={h.toString().padStart(2, "0")}>
                      {h.toString().padStart(2, "0")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <span className="flex items-center">:</span>
              <Select value={minute} onValueChange={setMinute}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {["00", "15", "30", "45"].map((m) => (
                    <SelectItem key={m} value={m}>
                      {m}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="AM">AM</SelectItem>
                  <SelectItem value="PM">PM</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button type="submit" className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            Add Reminder
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default AddReminderForm;
