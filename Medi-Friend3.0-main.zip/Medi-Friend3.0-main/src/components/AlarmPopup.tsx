import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, CheckCircle, X } from "lucide-react";
import { Reminder } from "@/types/auth";
import { getCurrentISTTime, formatTime12Hour } from "@/utils/time";

interface AlarmPopupProps {
  reminder: Reminder;
  onDismiss: () => void;
  onMarkAsTaken: () => void;
}

const AlarmPopup = ({ reminder, onDismiss, onMarkAsTaken }: AlarmPopupProps) => {
  const currentTime = formatTime12Hour(getCurrentISTTime());

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 animate-in fade-in">
      <Card className="w-full max-w-md p-6 space-y-4 alarm-pulse card-elevated">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-primary text-primary-foreground p-2 rounded-full">
              <AlertCircle className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold">💊 Time to take your medicine!</h2>
              <p className="text-sm text-muted-foreground">{currentTime} IST</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onDismiss}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="bg-secondary/50 p-4 rounded-lg space-y-2">
          <p className="font-semibold text-lg">{reminder.medicineName}</p>
          <p className="text-muted-foreground">{reminder.dosage}</p>
          <p className="text-sm">Scheduled: {reminder.time}</p>
        </div>

        <div className="flex gap-2">
          <Button onClick={onMarkAsTaken} className="flex-1">
            <CheckCircle className="h-4 w-4 mr-2" />
            Mark as Taken
          </Button>
          <Button onClick={onDismiss} variant="outline" className="flex-1">
            Dismiss
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default AlarmPopup;
