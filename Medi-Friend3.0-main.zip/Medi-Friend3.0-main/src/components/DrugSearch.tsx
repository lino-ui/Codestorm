import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface DrugInfo {
  name: string;
  genericName?: string;
  purpose?: string;
  warnings?: string[];
  activeIngredients?: string[];
}

const DrugSearch = () => {
  const { toast } = useToast();
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [drugInfo, setDrugInfo] = useState<DrugInfo | null>(null);

  const handleSearch = async () => {
    if (!query.trim()) {
      toast({
        title: "Enter Medicine Name",
        description: "Please enter a medicine name to search",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setDrugInfo(null);

    try {
      const response = await fetch(
        `https://api.fda.gov/drug/label.json?search=openfda.brand_name:"${query}"&limit=1`
      );

      if (!response.ok) {
        throw new Error("Drug not found");
      }

      const data = await response.json();

      if (data.results && data.results.length > 0) {
        const drug = data.results[0];
        setDrugInfo({
          name: drug.openfda?.brand_name?.[0] || query,
          genericName: drug.openfda?.generic_name?.[0],
          purpose: drug.purpose?.[0],
          warnings: drug.warnings?.slice(0, 3) || [],
          activeIngredients: drug.openfda?.substance_name || [],
        });
      } else {
        toast({
          title: "No Results Found",
          description: "Try searching with a different name",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Search Failed",
        description: "Could not fetch drug information. Try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="card-elevated">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="h-5 w-5" />
          Search Medicine Info 💡
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Enter medicine name..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
          <Button onClick={handleSearch} disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          </Button>
        </div>

        {drugInfo && (
          <div className="space-y-3 p-4 bg-secondary/50 rounded-lg">
            <div>
              <h3 className="font-bold text-lg">{drugInfo.name}</h3>
              {drugInfo.genericName && (
                <p className="text-sm text-muted-foreground">Generic: {drugInfo.genericName}</p>
              )}
            </div>

            {drugInfo.activeIngredients && drugInfo.activeIngredients.length > 0 && (
              <div>
                <h4 className="font-semibold text-sm">Active Ingredients:</h4>
                <p className="text-sm">{drugInfo.activeIngredients.join(", ")}</p>
              </div>
            )}

            {drugInfo.purpose && (
              <div>
                <h4 className="font-semibold text-sm">Purpose:</h4>
                <p className="text-sm">{drugInfo.purpose}</p>
              </div>
            )}

            {drugInfo.warnings && drugInfo.warnings.length > 0 && (
              <div>
                <h4 className="font-semibold text-sm">Warnings:</h4>
                <ul className="text-sm space-y-1 list-disc list-inside">
                  {drugInfo.warnings.map((warning, idx) => (
                    <li key={idx} className="text-muted-foreground">
                      {warning.substring(0, 150)}...
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DrugSearch;
