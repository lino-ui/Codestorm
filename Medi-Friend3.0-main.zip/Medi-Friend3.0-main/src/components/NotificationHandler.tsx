import { useEffect, useRef } from "react";
import { Reminder } from "@/types/auth";
import { getCurrentISTTime, formatTime12Hour, doTimesMatch } from "@/utils/time";

interface NotificationHandlerProps {
  reminders: Reminder[];
  enabled: boolean;
  onAlarmTrigger: (reminder: Reminder) => void;
}

const NotificationHandler = ({ reminders, enabled, onAlarmTrigger }: NotificationHandlerProps) => {
  const checkedReminders = useRef<Set<string>>(new Set());
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Create alarm sound (simple beep using Web Audio API)
    const createAlarmSound = () => {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 800;
      oscillator.type = "sine";
      gainNode.gain.value = 0.3;

      return { oscillator, audioContext };
    };

    const playAlarmSound = () => {
      const { oscillator, audioContext } = createAlarmSound();
      oscillator.start();
      setTimeout(() => {
        oscillator.stop();
        audioContext.close();
      }, 1000);
    };

    // Check reminders every second
    const interval = setInterval(() => {
      const currentTime = formatTime12Hour(getCurrentISTTime());

      reminders.forEach((reminder) => {
        if (reminder.status !== "upcoming") return;

        const reminderKey = `${reminder.id}-${reminder.time}`;
        
        // Check if this reminder has already been triggered
        if (checkedReminders.current.has(reminderKey)) return;

        // Check if current time matches reminder time
        if (doTimesMatch(currentTime, reminder.time)) {
          checkedReminders.current.add(reminderKey);

          if (enabled) {
            // Show browser notification
            if ("Notification" in window && Notification.permission === "granted") {
              new Notification("💊 Medicine Reminder", {
                body: `Time to take ${reminder.medicineName} - ${reminder.dosage}`,
                icon: "/favicon.ico",
                tag: reminder.id,
                requireInteraction: true,
              });
            }

            // Play alarm sound
            try {
              playAlarmSound();
            } catch (error) {
              console.error("Failed to play alarm sound:", error);
            }
          }

          // Trigger in-app popup
          onAlarmTrigger(reminder);
        }
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [reminders, enabled, onAlarmTrigger]);

  return null;
};

export default NotificationHandler;
