import { UserData, User, Reminder } from "@/types/auth";

const STORAGE_KEY = "medifriend_data";

export const getStorageData = (): UserData => {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) {
    return {
      users: [],
      reminders: {},
      notificationSettings: {},
    };
  }
  return JSON.parse(data);
};

export const saveStorageData = (data: UserData) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};

export const findUser = (email: string): User | undefined => {
  const data = getStorageData();
  return data.users.find((u) => u.email === email);
};

export const createUser = (user: User): boolean => {
  const data = getStorageData();
  if (findUser(user.email)) {
    return false;
  }
  data.users.push(user);
  data.reminders[user.email] = [];
  data.notificationSettings[user.email] = true;
  saveStorageData(data);
  return true;
};

export const getUserReminders = (email: string): Reminder[] => {
  const data = getStorageData();
  return data.reminders[email] || [];
};

export const saveUserReminders = (email: string, reminders: Reminder[]) => {
  const data = getStorageData();
  data.reminders[email] = reminders;
  saveStorageData(data);
};

export const getNotificationSetting = (email: string): boolean => {
  const data = getStorageData();
  return data.notificationSettings[email] ?? true;
};

export const setNotificationSetting = (email: string, enabled: boolean) => {
  const data = getStorageData();
  data.notificationSettings[email] = enabled;
  saveStorageData(data);
};
