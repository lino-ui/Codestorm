/**
 * Get current time in IST (Indian Standard Time)
 * IST is UTC+5:30
 */
export const getCurrentISTTime = (): Date => {
  const now = new Date();
  // Convert to IST
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  const istTime = new Date(utc + 3600000 * 5.5);
  return istTime;
};

/**
 * Format time to 12-hour format with AM/PM
 */
export const formatTime12Hour = (date: Date): string => {
  let hours = date.getHours();
  const minutes = date.getMinutes();
  const ampm = hours >= 12 ? "PM" : "AM";
  hours = hours % 12;
  hours = hours ? hours : 12;
  const minutesStr = minutes < 10 ? "0" + minutes : minutes;
  return `${hours}:${minutesStr} ${ampm}`;
};

/**
 * Check if two times match (ignoring seconds)
 */
export const doTimesMatch = (time1: string, time2: string): boolean => {
  return time1.trim().toUpperCase() === time2.trim().toUpperCase();
};

/**
 * Parse 12-hour time string to Date object in IST
 */
export const parseTime12Hour = (timeStr: string): Date | null => {
  const match = timeStr.match(/(\d+):(\d+)\s*(AM|PM)/i);
  if (!match) return null;

  let hours = parseInt(match[1]);
  const minutes = parseInt(match[2]);
  const period = match[3].toUpperCase();

  if (period === "PM" && hours !== 12) {
    hours += 12;
  } else if (period === "AM" && hours === 12) {
    hours = 0;
  }

  const now = getCurrentISTTime();
  now.setHours(hours, minutes, 0, 0);
  return now;
};
