import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Pill, Calendar, Bell, Search } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already logged in
    const sessionUser =
      localStorage.getItem("medifriend_session") || sessionStorage.getItem("medifriend_session");
    if (sessionUser) {
      navigate("/dashboard");
    }
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-4xl w-full text-center space-y-8">
        {/* Logo and Title */}
        <div className="space-y-4">
          <div className="flex justify-center">
            <div className="bg-primary text-primary-foreground p-6 rounded-full">
              <Pill className="h-16 w-16" />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold">Medi-Friend</h1>
          <p className="text-xl md:text-2xl text-muted-foreground">
            Never Miss a Dose Again 💊
          </p>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 my-12">
          <div className="bg-card p-6 rounded-lg card-elevated space-y-3">
            <div className="bg-primary/10 text-primary p-3 rounded-full w-fit mx-auto">
              <Calendar className="h-6 w-6" />
            </div>
            <h3 className="font-semibold">Smart Reminders</h3>
            <p className="text-sm text-muted-foreground">
              Set personalized medicine reminders with easy 12-hour time format
            </p>
          </div>

          <div className="bg-card p-6 rounded-lg card-elevated space-y-3">
            <div className="bg-primary/10 text-primary p-3 rounded-full w-fit mx-auto">
              <Bell className="h-6 w-6" />
            </div>
            <h3 className="font-semibold">Multi-Channel Alerts</h3>
            <p className="text-sm text-muted-foreground">
              Get notified via browser, email, and WhatsApp when it's time
            </p>
          </div>

          <div className="bg-card p-6 rounded-lg card-elevated space-y-3">
            <div className="bg-primary/10 text-primary p-3 rounded-full w-fit mx-auto">
              <Search className="h-6 w-6" />
            </div>
            <h3 className="font-semibold">Drug Information</h3>
            <p className="text-sm text-muted-foreground">
              Instant access to medicine details and side effects
            </p>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" onClick={() => navigate("/auth")} className="text-lg px-8">
            Get Started
          </Button>
          <Button size="lg" variant="outline" onClick={() => navigate("/auth")} className="text-lg px-8">
            Login
          </Button>
        </div>

        <p className="text-sm text-muted-foreground">
          Perfect for elderly patients, chronic illness management, and anyone with multiple medications
        </p>
      </div>
    </div>
  );
};

export default Index;
