import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { LogOut, Pill, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  getUserReminders,
  saveUserReminders,
  getNotificationSetting,
  setNotificationSetting,
} from "@/utils/storage";
import { Reminder } from "@/types/auth";
import AddReminderForm from "@/components/AddReminderForm";
import ReminderList from "@/components/ReminderList";
import DrugSearch from "@/components/DrugSearch";
import AlarmPopup from "@/components/AlarmPopup";
import NotificationHandler from "@/components/NotificationHandler";

const Dashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState<string>("");
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [activeAlarm, setActiveAlarm] = useState<Reminder | null>(null);

  useEffect(() => {
    const sessionUser =
      localStorage.getItem("medifriend_session") || sessionStorage.getItem("medifriend_session");

    if (!sessionUser) {
      navigate("/auth");
      return;
    }

    setCurrentUser(sessionUser);
    const userReminders = getUserReminders(sessionUser);
    setReminders(userReminders);
    const notifSetting = getNotificationSetting(sessionUser);
    setNotificationsEnabled(notifSetting);

    // Request notification permission
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("medifriend_session");
    sessionStorage.removeItem("medifriend_session");
    toast({
      title: "Logged Out",
      description: "Come back soon! 👋",
    });
    navigate("/auth");
  };

  const handleNotificationToggle = (checked: boolean) => {
    setNotificationsEnabled(checked);
    setNotificationSetting(currentUser, checked);
    toast({
      title: checked ? "Notifications Enabled" : "Notifications Disabled",
      description: checked
        ? "You'll receive reminders for your medicines"
        : "Reminders will be silent",
    });
  };

  const handleAddReminder = (reminder: Reminder) => {
    const updated = [...reminders, reminder];
    setReminders(updated);
    saveUserReminders(currentUser, updated);
  };

  const handleUpdateReminder = (id: string, updates: Partial<Reminder>) => {
    const updated = reminders.map((r) => (r.id === id ? { ...r, ...updates } : r));
    setReminders(updated);
    saveUserReminders(currentUser, updated);
  };

  const handleDeleteReminder = (id: string) => {
    const updated = reminders.filter((r) => r.id !== id);
    setReminders(updated);
    saveUserReminders(currentUser, updated);
  };

  const handleDismissAlarm = () => {
    setActiveAlarm(null);
  };

  const handleMarkAsTaken = () => {
    if (activeAlarm) {
      handleUpdateReminder(activeAlarm.id, { status: "taken" });
    }
    setActiveAlarm(null);
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-primary text-primary-foreground p-3 rounded-full">
              <Pill className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">Medi-Friend</h1>
              <p className="text-sm text-muted-foreground">{currentUser}</p>
            </div>
          </div>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>

        {/* Notification Toggle */}
        <div className="bg-card p-4 rounded-lg card-elevated flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Label htmlFor="notifications" className="cursor-pointer">
              Enable Notifications
            </Label>
          </div>
          <Switch
            id="notifications"
            checked={notificationsEnabled}
            onCheckedChange={handleNotificationToggle}
          />
        </div>

        {/* Drug Search */}
        <DrugSearch />

        {/* Add Reminder Form */}
        <AddReminderForm onAdd={handleAddReminder} />

        {/* Reminders List */}
        <ReminderList
          reminders={reminders}
          onUpdate={handleUpdateReminder}
          onDelete={handleDeleteReminder}
        />

        {/* Alarm Popup */}
        {activeAlarm && (
          <AlarmPopup
            reminder={activeAlarm}
            onDismiss={handleDismissAlarm}
            onMarkAsTaken={handleMarkAsTaken}
          />
        )}

        {/* Background Notification Handler */}
        <NotificationHandler
          reminders={reminders}
          enabled={notificationsEnabled}
          onAlarmTrigger={setActiveAlarm}
        />
      </div>
    </div>
  );
};

export default Dashboard;
