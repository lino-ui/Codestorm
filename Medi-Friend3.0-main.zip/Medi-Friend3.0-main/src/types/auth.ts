export interface User {
  email: string;
  password: string;
  whatsapp?: string;
  gmail?: string;
}

export interface Reminder {
  id: string;
  medicineName: string;
  dosage: string;
  time: string; // Format: "HH:MM AM/PM"
  status: "upcoming" | "taken" | "missed";
  createdAt: string;
}

export interface UserData {
  users: User[];
  reminders: Record<string, Reminder[]>;
  notificationSettings: Record<string, boolean>;
}
